Regardings the iTunesArtwork and iTunesArtwork@2x extension.

According to https://developer.apple.com/library/ios/qa/qa1686/_index.html, the iTunesArtwork and iTunesArtwork@2x should not have extension. However, in reallife, you will need the `.png` extension for iTuneConnect submission. So we append the `.png` to those files.

In case you are doing Ad_hoc or Enterprise distirbution, you will want to remove the `.png` extension before adding those files into XCode.